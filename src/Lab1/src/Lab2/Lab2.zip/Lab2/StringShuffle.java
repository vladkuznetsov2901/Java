package Lab2;

import java.util.Scanner;

public class StringShuffle {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Insert your string: ");
        String str = input.next();
        for (int i = 0; i < str.length(); i++) {
            System.out.println(str.substring(i) + str.substring(0, i));
        }
    }
}
