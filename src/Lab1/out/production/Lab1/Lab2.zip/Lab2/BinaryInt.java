package Lab2;

import java.util.Scanner;

public class BinaryInt {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        System.out.println("Decimal: " + n);
        System.out.println("Binary: " + Integer.toString(n, 2));
        System.out.println("Octal: " + Integer.toString(n, 8));
        System.out.println("Hex: " + Integer.toString(n, 16));
    }
}
