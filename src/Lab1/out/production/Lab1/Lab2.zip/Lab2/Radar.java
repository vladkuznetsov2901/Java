package Lab2;

public class Radar {
    public static void main(String[] args) {

    }
}
