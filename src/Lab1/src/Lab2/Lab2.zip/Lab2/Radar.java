package Lab2;

import java.util.Scanner;

public class Radar {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter r: ");
        int r = input.nextInt();
        System.out.println("Enter R: ");
        int R = input.nextInt();

        System.out.println("Enter x: ");
        double x = input.nextDouble();
        System.out.println("Enter y: ");
        double y = input.nextDouble();

        double distance = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));

        if (distance > R){
            System.out.println("Не обнаружен");
        } else if (distance > r && distance <= R) {
            System.out.println("Обнаружен");
        } else if (distance <= r) {
            System.out.println("Тревога");
        }

    }



}
